
/**
 * Write a description of class VeiculoNaoExistenteException here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class VeiculoNaoExistenteException extends Exception {
 
  public VeiculoNaoExistenteException() {
      super();
    }
    
  public VeiculoNaoExistenteException(String msg) {
    super(msg);    
  }
    
}
